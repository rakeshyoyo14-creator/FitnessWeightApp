package com.rakesh.fitnessidealweight

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private val MEN_CM_TO_KG = mapOf(
    155 to 56, 158 to 58, 160 to 59, 163 to 60, 165 to 62, 168 to 64,
    170 to 66, 173 to 68, 175 to 69, 178 to 72, 180 to 74, 183 to 76
)
private val WOMEN_CM_TO_KG = mapOf(
    142 to 46, 145 to 47, 147 to 49, 150 to 50, 152 to 51, 155 to 53,
    158 to 54, 160 to 56, 163 to 58, 165 to 60, 168 to 62, 170 to 64
)

private fun nearestBaseKg(isMale: Boolean, heightCm: Int): Int {
    val table = if (isMale) MEN_CM_TO_KG else WOMEN_CM_TO_KG
    val nearestKey = table.keys.minByOrNull { h -> abs(h - heightCm) } ?: table.keys.first()
    return table[nearestKey]!!
}

private fun ageAdjustment(age: Int): Int {
    return if (age <= 30) 0 else ((age - 31) / 10) + 1
}

@Composable
fun App() {
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Content()
        }
    }
}

@Composable
fun Content() {
    var gender by remember { mutableStateOf(stringResource(R.string.male)) }
    var unit by remember { mutableStateOf("cm") }
    var cmHeight by remember { mutableStateOf("") }
    var feet by remember { mutableStateOf("") }
    var inches by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }

    val isMale = gender == stringResource(R.string.male)

    val heightCm = when (unit) {
        "cm" -> cmHeight.toIntOrNull()
        "ft" -> {
            val f = feet.toIntOrNull() ?: 0
            val i = inches.toIntOrNull() ?: 0
            (f * 30.48 + i * 2.54).toInt()
        }
        else -> null
    }

    val resultText = remember(gender, unit, cmHeight, feet, inches, age, weight) {
        val h = heightCm
        val a = age.toIntOrNull()
        val w = weight.toFloatOrNull()

        if (h == null || a == null) {
            "कृपया कद और उम्र दर्ज करें / Please enter height & age."
        } else {
            val base = nearestBaseKg(isMale, h)
            val ideal = base + ageAdjustment(a)
            if (w == null) {
                "Ideal weight for $gender at $h cm & age $a ≈ $ideal kg"
            } else {
                val diff = (w - ideal).roundToInt()
                val status = when {
                    diff > 0 -> "लगभग $diff किलो ज्यादा (above ideal)"
                    diff < 0 -> "लगभग ${-diff} किलो कम (below ideal)"
                    else -> "बिल्कुल सही (right on the ideal)"
                }
                "आदर्श वज़न ≈ $ideal kg • $status."
            }
        }
    }

    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.title), style = MaterialTheme.typography.titleLarge)

        // Gender selection
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(stringResource(R.string.male), stringResource(R.string.female)).forEach {
                FilterChip(
                    selected = gender == it,
                    onClick = { gender = it },
                    label = { Text(it) }
                )
            }
        }

        // Height unit selector
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = unit == "cm",
                onClick = { unit = "cm" },
                label = { Text("Centimeters") }
            )
            FilterChip(
                selected = unit == "ft",
                onClick = { unit = "ft" },
                label = { Text("Feet & Inches") }
            )
        }

        if (unit == "cm") {
            OutlinedTextField(
                value = cmHeight,
                onValueChange = { cmHeight = it.filter { ch -> ch.isDigit() } },
                label = { Text("कद (सेमी)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = feet,
                    onValueChange = { feet = it.filter { ch -> ch.isDigit() } },
                    label = { Text("कद (फुट)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = inches,
                    onValueChange = { inches = it.filter { ch -> ch.isDigit() } },
                    label = { Text("कद (इंच)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        OutlinedTextField(
            value = age,
            onValueChange = { age = it.filter { ch -> ch.isDigit() } },
            label = { Text(stringResource(R.string.age)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = weight,
            onValueChange = { weight = it.filter { ch -> ch.isDigit() || ch == '.' } },
            label = { Text(stringResource(R.string.weight)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Text(resultText, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 8.dp))
        Text(stringResource(R.string.note), style = MaterialTheme.typography.bodySmall)
    }
}
